# Fomebrava — Team Charter dos Agentes

## Missão

Os agentes do Fomebrava existem para elevar a qualidade do produto sem violar as regras de negócio, a segurança multi-tenant, a integridade financeira ou o fluxo operacional.

O Brain do projeto é a fonte canônica de contexto. Em caso de dúvida, o agente deve priorizar:

1. integridade financeira;
2. isolamento entre tenants;
3. integridade dos pedidos;
4. operação da cozinha;
5. experiência do cliente;
6. experiência administrativa;
7. conveniência de desenvolvimento.

## Regras globais obrigatórias

Todo agente deve:

- entender o fluxo afetado antes de editar código;
- identificar todas as entidades de banco envolvidas;
- verificar `tenant_id` sempre que houver dado pertencente a uma organização;
- revisar RLS quando houver leitura, escrita ou nova entidade;
- avaliar impacto em pedidos, pagamentos, Realtime e financeiro;
- preservar compatibilidade com os fluxos existentes;
- evitar duplicar abstrações já existentes;
- não confiar no frontend para decisões críticas;
- tratar o backend como autoridade para pagamento e regras sensíveis;
- evitar mudanças fora do próprio domínio sem handoff explícito;
- documentar decisões que alterem arquitetura ou regra de negócio;
- entregar código pronto para revisão, sem TODOs vagos ou gambiarras silenciosas.

## Regra de perfeição pragmática

"Buscar perfeição" significa:

- código correto;
- comportamento previsível;
- clareza arquitetural;
- segurança;
- testes adequados;
- observabilidade suficiente;
- simplicidade proporcional ao problema.

Não significa criar abstrações desnecessárias, aumentar complexidade ou reescrever código estável sem benefício concreto.

## Handoff

Quando uma mudança atravessar dois ou mais domínios, o agente responsável pela alteração principal deve registrar:

- o que mudou;
- quais contratos foram afetados;
- quais arquivos/tabelas/endpoints foram tocados;
- quais riscos permanecem;
- qual agente precisa revisar a parte adjacente.

## Definition of Done comum

Uma tarefa só é considerada concluída quando:

- o comportamento esperado foi implementado;
- casos de erro relevantes foram tratados;
- riscos de tenant foram revisados;
- regras de pedido/pagamento foram preservadas;
- testes foram criados ou atualizados quando aplicável;
- lint/build/testes relevantes passam;
- comentários/documentação afetados continuam verdadeiros;
- não há segredo ou dado sensível exposto.
