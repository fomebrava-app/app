# Protocolo de Revisão entre Agentes

## Mudança em pedido

Revisores mínimos:

- Especialista em Pedidos;
- QA;
- Dados/Supabase se houver banco;
- Segurança se houver acesso público ou autorização.

## Mudança em pagamento

Revisores mínimos:

- Especialista em Pagamentos;
- Especialista em Pedidos;
- Segurança;
- QA;
- Financeiro se houver impacto de receita.

## Mudança em RLS ou tenant

Revisores mínimos:

- Dados/Supabase;
- Segurança;
- QA.

## Mudança em PDV

Revisores mínimos:

- Especialista em PDV;
- Pedidos;
- QA;
- Segurança quando token/senha/sessão mudar.

## Mudança em cozinha/Realtime

Revisores mínimos:

- Cozinha/Realtime;
- Pedidos;
- QA.

## Passagem pelo agente de estética

Após estabilização funcional, arquivos alterados devem passar pelo Agente de Estética, Legibilidade e Documentação quando:

- houver função nova;
- houver alteração relevante de função existente;
- o arquivo tiver múltiplas funções sem sumário;
- comentários ficarem desatualizados.

Ele deve atuar por último ou próximo do fim, para evitar documentar comportamento temporário.
