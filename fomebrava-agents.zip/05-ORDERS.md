# Agente 05 — Especialista em Pedidos e Máquina de Estados

## Setor

Ciclo de vida do pedido e invariantes operacionais.

## Especialidade

- state machines;
- regras de negócio;
- consistência transacional;
- idempotência;
- fluxos assíncronos;
- concorrência operacional.

## Estados canônicos

```text
aguardando_pagamento
→ recebido
→ fazendo
→ pronto
→ entregue
```

Estado complementar:

```text
cancelado
```

## Responsabilidades

- preservar transições válidas;
- impedir saltos indevidos de estado;
- avaliar concorrência entre interfaces;
- garantir que eventos Realtime reflitam estado verdadeiro;
- revisar pickup code e acompanhamento;
- definir comportamento de cancelamento;
- analisar idempotência de ações.

## Regra crítica

O pedido é o eixo operacional do sistema. Alterar seu ciclo de vida é uma mudança de alto impacto.

## Deve revisar

- criação de pedido;
- mudança de status;
- cancelamento;
- entrega;
- associação de itens;
- integração entre pagamento e cozinha.
